package com.ellomix.android.ellomix.Model;

/**
 * Created by ATH-AJT2437 on 1/21/2017.
 */

public class UserLab {
}
