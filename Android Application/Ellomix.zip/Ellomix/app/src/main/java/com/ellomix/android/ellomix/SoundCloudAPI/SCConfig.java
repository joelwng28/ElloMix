package com.ellomix.android.ellomix.SoundCloudAPI;

/**
 * Created by alepena01 on 10/27/16.
 */

public class SCConfig {

    public static final String CLIENT_ID = "3e7f2924c47462bf79720ae5995194de";
    public static final String API_URL = "https://api.soundcloud.com";


}
