package com.ellomix.android.ellomix.Model;

/**
 * Created by ATH-AJT2437 on 12/22/2016.
 */

public enum Sources {
    SOUNDCLOUD,
    SPOTIFY,
    YOUTUBE
}
