//
//  ChatFeedViewController.swift
//  Ellomix
//
//  Created by Akshay Vyas on 2/16/17.
//  Copyright © 2017 Akshay Vyas. All rights reserved.
//

import UIKit

class ChatFeedViewController: UITableViewController {
    
    
    override func viewDidLoad() {
        
    }
}
